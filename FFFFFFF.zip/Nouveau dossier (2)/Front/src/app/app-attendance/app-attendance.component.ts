import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';
import { AuthService } from '../auth.service';
import { Attendance } from './attendance.model';

@Component({
  selector: 'app-attendance',
  templateUrl: './app-attendance.component.html',
  styleUrls: ['./app-attendance.component.scss']
})
export class AttendanceComponent implements OnInit {
  userId: number | null = null;
  user: any; // Adjust type/interface as necessary
  attendances: Attendance[] = [];

  constructor(
    private apiService: ApiService,
    private route: ActivatedRoute,
    private authService: AuthService // Inject AuthService
  ) {}

  ngOnInit(): void {
    const userEmail = this.authService.getCurrentUserEmail();
    console.log('Current User Email:', userEmail);
    if (userEmail) {
      this.apiService.getUserIdByEmail(userEmail).subscribe(
        (userId: number | null) => {
          if (userId !== null) {
            this.userId = userId;
            this.fetchUserAttendance(userId);
          } else {
            console.error('User ID not found for email:', userEmail);
            // Handle the case where userId is null (e.g., show an error message)
          }
        },
        (error: any) => console.error('Error fetching user ID:', error)
      );
    } else {
      console.error('No user email found.');
      // Handle the case where userEmail is null (e.g., redirect to login)
    }
  }

  fetchUserAttendance(userId: number): void {
    this.apiService.getUserAttendance(userId).subscribe(
      attendances => {
        this.attendances = attendances;
      },
      error => {
        console.error('Error fetching user attendance:', error);
      }
    );
  }

  checkIn(): void {
    if (this.userId !== null) {
      this.apiService.checkIn(this.userId).subscribe(
        attendance => {
          console.log('Check-in successful:', attendance);
          this.attendances.push(attendance); // Update local list of attendances
        },
        error => {
          console.error('Error checking in:', error);
          // Handle error (e.g., show error message)
        }
      );
    } else {
      console.error('Invalid user ID for check-in:', this.userId);
      // Handle invalid user ID case (e.g., redirect to error page or show message)
    }
  }

  checkOut(): void {
    if (this.userId !== null) {
      this.apiService.checkOut(this.userId).subscribe(
        attendance => {
          console.log('Check-out successful:', attendance);
          // Update local list of attendances with the updated record
          const index = this.attendances.findIndex(a => a.id === attendance.id);
          if (index !== -1) {
            this.attendances[index] = attendance; 
          }
        },
        error => {
          console.error('Error checking out:', error);
          // Handle error (e.g., show error message)
        }
      );
    } else {
      console.error('Invalid user ID for check-out:', this.userId);
      // Handle invalid user ID case (e.g., redirect to error page or show message)
    }
  }
}
