// src/app/user.model.ts
export interface User {
    id: number;
    fullName: string;
    email: string;
    // Add other user properties as needed
  }
  