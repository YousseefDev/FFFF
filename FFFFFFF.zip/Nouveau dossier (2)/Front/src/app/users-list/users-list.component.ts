import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { User } from '../User.model';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit {
  userProfile: any;
  users: User[] = [];
  editMode = false;
  editUserProfile: any;
  selectedUserId: number | null = null;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.fetchUsers();
  }

  fetchUsers(): void {
    this.apiService.getAllUsers().subscribe(
      users => {
        this.users = users;
      },
      error => {
        console.error('Error fetching users:', error);
      }
    );
  }

  fetchUserProfile(userId: number) { // Change parameter type to number
    this.apiService.getUserProfile1(userId).subscribe(
      (data: User) => {
        this.userProfile = data;
        this.editUserProfile = { ...data }; // Clone the user profile for editing
      },
      (error) => {
        console.error('Error fetching user profile:', error);
      }
    );
  }
  modifyUser(userId: number) { // Change parameter type to number
    this.selectedUserId = userId;
    this.fetchUserProfile(userId);
    this.enableEditMode();
  }

  enableEditMode() {
    this.editMode = true;
  }

  cancelEdit() {
    this.editMode = false;
    this.editUserProfile = null;
  }
  
  updateUserProfile(): void {
    console.log('Updating user profile with:', this.editUserProfile); // Log to check data before sending
    
    if (this.userProfile && this.editUserProfile) {
      // Assuming you have implemented updateUserProfile method in ApiService
      this.apiService.updateUserProfile(this.userProfile.id, this.editUserProfile).subscribe(
        (updatedProfile) => {
          console.log('User profile updated:', updatedProfile);
          this.userProfile = updatedProfile;
          this.cancelEdit();
        },
        (error) => {
          console.error('Error updating user profile:', error);
        }
      );
    }
  }}