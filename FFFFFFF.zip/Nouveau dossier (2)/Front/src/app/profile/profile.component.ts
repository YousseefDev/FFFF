import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { ActivatedRoute } from '@angular/router';
import { User } from '../User.model'; // Adjust the import as necessary

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  userProfile: any;
  user: User | null = null;

  constructor(
    private apiService: ApiService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    console.log('ProfileComponent initialized');
    this.apiService.getUserProfile().subscribe(
      data => {
        console.log('User profile data received:', data);
        this.userProfile = data;
      },
      error => {
        console.error('Error fetching user profile', error);
      }
    );
  
    const userId = +this.route.snapshot.paramMap.get('id')!;
    if (userId) {
      console.log('Fetching user profile for user ID:', userId);
      this.fetchUserProfile(userId);
    }
  }
  
  fetchUserProfile(id: number): void {
    console.log('Fetching user profile data for user ID:', id);
    this.apiService.getUserProfile1(id).subscribe(
      user => {
        console.log('User profile data received:', user);
        this.user = user;
      },
      error => {
        console.error('Error fetching user profile:', error);
      }
    );
  }
}  