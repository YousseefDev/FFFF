import { Component, OnInit } from '@angular/core';
import { Post } from '../post/post.model';
import { PostService } from '../post/post.service';
import { ApiService } from '../api.service';
import { AuthService } from '../auth.service'; // Import AuthService

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  posts: Post[] = [];
  days: string[] = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  calendar: { date: number, today: boolean }[][] = [];
  pendingAuthRequestsCount: number = 0;
  pendingLeaveRequestsCount: number = 0;
  pendingLoanRequestsCount: number = 0;
  pendingPersonalSituationRequestsCount: number = 0;
  pendingDocumentRequestsCount: number = 0;
  pendingAdminRequestsCount: number = 0;

  userId: number | null = null; // Initialize userId as null

  requestCounts: any = {};

  constructor(
    private postService: PostService,
    private apiService: ApiService,
    private authService: AuthService // Inject AuthService
  ) {}

  ngOnInit(): void {
    const userEmail = this.authService.getCurrentUserEmail();
    console.log('Current User Email:', userEmail);
    if (userEmail) {
      this.apiService.getUserIdByEmail(userEmail).subscribe(
        (userId: number | null) => {
          if (userId !== null) {  
            this.userId = userId;
            this.fetchUserRequestCounts(userId); // Fetch user request counts once you have userId
          } else {
            console.error('User ID not found for email:', userEmail);
            // Handle the case where userId is null (e.g., show an error message)
          }
        },
        (error: any) => console.error('Error fetching user ID:', error)
      );
    }
    
    this.loadPosts();
    this.generateCalendar();
  }

  loadPosts(): void {
    this.postService.getPosts().subscribe(
      posts => this.posts = posts,
      error => console.error('Error fetching posts:', error)
    );
  }

  generateCalendar(): void {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();

    let dayCounter = 1;
    let week: { date: number, today: boolean }[] = [];

    for (let i = 0; i < firstDayOfMonth; i++) {
      week.push({ date: 0, today: false });
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const currentDate = new Date(currentYear, currentMonth, day);
      const isToday = this.isSameDay(currentDate, new Date());

      week.push({ date: day, today: isToday });

      if (week.length === 7) {
        this.calendar.push(week);
        week = [];
      }
    }

    if (week.length > 0) {
      while (week.length < 7) {
        week.push({ date: 0, today: false });
      }
      this.calendar.push(week);
    }
  }

  isSameDay(date1: Date, date2: Date): boolean {
    return date1.getFullYear() === date2.getFullYear() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getDate() === date2.getDate();
  }

  fetchUserRequestCounts(userId: number): void {
    this.apiService.getRequestCounts(userId).subscribe(
      counts => {
        this.requestCounts = counts;
        this.pendingLeaveRequestsCount = counts.leaveRequests || 0;
        this.pendingLoanRequestsCount = counts.loanRequests || 0;
        this.pendingDocumentRequestsCount = counts.documentRequests || 0;
        this.pendingPersonalSituationRequestsCount = counts.personalSituationRequests || 0;
        this.pendingAuthRequestsCount = counts.authRequests || 0;
      },
      error => {
        console.error('Error fetching user request counts:', error);
      }
    );
  }
}
