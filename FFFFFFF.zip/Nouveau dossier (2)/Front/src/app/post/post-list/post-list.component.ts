import { Component, OnInit } from '@angular/core';
import { Post } from '../post.model';
import { PostService } from '../post.service';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.scss']
})
export class PostListComponent implements OnInit {
  posts: Post[] = [];
  days: string[] = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  calendar: { date: number, today: boolean }[][] = [];
  pendingAuthRequestsCount: number = 0;
  pendingLeaveRequestsCount: number = 0;
  pendingLoanRequestsCount: number = 0;
  pendingPersonalSituationRequestsCount: number = 0;
  pendingDocumentRequestsCount: number = 0;
  pendingAdminRequestsCount: number = 0;
  nbusers:number=0;

  constructor(private postService: PostService, private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadPosts();
    this.generateCalendar();
    this.getPendingRequestsCounts(); // Call the method to get pending requests counts
    this.getnbusers(); // Call the method to get pending requests counts

  }
  getnbusers():void{
    this.apiService.countAllusers().subscribe(
      count => this.nbusers = count,
      error => console.error('Error fetching pending auth requests count:', error)

    )
  }

  getPendingRequestsCounts(): void {
    this.apiService.countAllPendingRequests().subscribe(
      count => this.pendingAuthRequestsCount = count,
      error => console.error('Error fetching pending auth requests count:', error)
    );

    this.apiService.countAllPendingAdminRequests().subscribe(
      count => this.pendingAdminRequestsCount = count,
      error => console.error('Error fetching pending admin requests count:', error)
    );
  }
  loadPosts(): void {
    this.postService.getPosts().subscribe(
      posts => this.posts = posts,
      error => console.error('Error fetching posts:', error)
    );
  }

  // Method to add a new post to the list
  addNewPost(post: Post): void {
    this.posts.push(post); // Add the new post to the current list
  }

  generateCalendar(): void {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();

    let dayCounter = 1;
    let week: { date: number, today: boolean }[] = [];

    // Fill in empty days before the start of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
      week.push({ date: 0, today: false });
    }

    // Fill in days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const currentDate = new Date(currentYear, currentMonth, day);
      const isToday = this.isSameDay(currentDate, new Date());

      week.push({ date: day, today: isToday });

      // If we have filled a week, add it to the calendar and reset the week
      if (week.length === 7) {
        this.calendar.push(week);
        week = [];
      }
    }

    // If the last week is not complete, add it to the calendar
    if (week.length > 0) {
      while (week.length < 7) {
        week.push({ date: 0, today: false });
      }
      this.calendar.push(week);
    }
  }

  isSameDay(date1: Date, date2: Date): boolean {
    return date1.getFullYear() === date2.getFullYear() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getDate() === date2.getDate();
  }

 
}
