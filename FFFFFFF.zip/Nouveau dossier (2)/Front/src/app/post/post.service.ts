// src/app/services/post.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Post } from './post.model';
import { AuthService } from '../auth.service';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  private apiUrl = 'http://localhost:8070/api/v1/posts';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const accessToken = this.authService.getCurrentUser();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    });
  }

  getPosts(): Observable<Post[]> {
    const headers = this.getHeaders();
    return this.http.get<Post[]>(this.apiUrl, { headers });
  }

  addPost(post: Post): Observable<Post> {
    const headers = this.getHeaders();
    return this.http.post<Post>(this.apiUrl, post, { headers });
  }
}
