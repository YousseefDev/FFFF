// src/app/models/post.model.ts
export interface Post {
    id?: number;
    title: string;
    subject: string;
    imageUrl: string;
  }
  