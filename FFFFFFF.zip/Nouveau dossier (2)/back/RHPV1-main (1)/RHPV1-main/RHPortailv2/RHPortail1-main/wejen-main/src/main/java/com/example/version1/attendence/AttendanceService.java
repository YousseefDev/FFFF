package com.example.version1.attendence;

import com.example.version1.attendence.Attendance;
import com.example.version1.attendence.AttendanceRepository;
import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private UserRepository userRepository;

    public Attendance checkIn(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Check if there's an existing check-in record for today
        Optional<Attendance> existingAttendanceOptional = attendanceRepository.findFirstByUserAndDateOrderByCheckInTimeDesc(user, LocalDate.now());

        if (existingAttendanceOptional.isPresent()) {
            Attendance existingAttendance = existingAttendanceOptional.get();
            if (existingAttendance.getCheckOutTime() == null) {
                throw new RuntimeException("User already checked in today.");
            }
        }

        Attendance newAttendance = new Attendance();
        newAttendance.setUser(user);
        newAttendance.setDate(LocalDate.now());
        newAttendance.setCheckInTime(LocalTime.now());
        return attendanceRepository.save(newAttendance);
    }


    public Attendance checkOut(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Find the latest check-in record for today
        Optional<Attendance> attendanceOptional = attendanceRepository.findFirstByUserAndDateOrderByCheckInTimeDesc(user, LocalDate.now());

        Attendance attendance = attendanceOptional.orElseThrow(() -> new RuntimeException("Check-in record not found"));

        // Check if already checked out
        if (attendance.getCheckOutTime() != null) {
            throw new RuntimeException("User already checked out today.");
        }

        attendance.setCheckOutTime(LocalTime.now());
        return attendanceRepository.save(attendance);
    }


    public List<Attendance> getUserAttendance(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return attendanceRepository.findByUserId(userId);
    }
}