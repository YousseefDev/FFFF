package com.example.version1.requests.document;

import com.example.version1.requests.Request;
import com.example.version1.requests.document.DocumentRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentRequestRepository extends JpaRepository<DocumentRequest, Long> {
    List<DocumentRequest> findByUserId(Long userId);
    List<DocumentRequest> findByStatus(String status);
    int countByStatus(String status);
    Long countByUserId(Long userId);


}
