package com.example.version1.admin;

import com.example.version1.requests.Leave.LeaveRequest;
import com.example.version1.requests.auth.AuthRequest;
import com.example.version1.requests.auth.AuthRequestService;
import com.example.version1.requests.document.DocumentRequestService;
import com.example.version1.requests.loan.LoanRequestService;
import com.example.version1.requests.personal.PersonalSituationRequestService;
import com.example.version1.requests.Leave.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/requests/admin")
public class admin {

    @Autowired
    private LoanRequestService loanRequestService;

    @Autowired
    private PersonalSituationRequestService personalSituationRequestService;

    @Autowired
    private DocumentRequestService documentRequestService;

    @Autowired
    private LeaveRequestService leaveRequestService;

    @Autowired
    private AuthRequestService authRequestService;

    // Leave Requests

    @GetMapping("/pending/count")
    public ResponseEntity<Integer> countAllPendingRequests(Authentication authentication)
            throws AuthenticationException {
        validateAuthentication(authentication);
        int count = leaveRequestService.countPendingLeaveRequests() + authRequestService.countPendingAuthRequests();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }

    @GetMapping("/leave-requests")
    public ResponseEntity<List<LeaveRequest>> getLeaveRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<LeaveRequest> leaveRequests = leaveRequestService.getAllLeaveRequests();
        return new ResponseEntity<>(leaveRequests, HttpStatus.OK);
    }

    @GetMapping("/leave-requests/pending")
    public ResponseEntity<List<LeaveRequest>> getPendingLeaveRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<LeaveRequest> leaveRequests = leaveRequestService.getPendingLeaveRequests();
        return new ResponseEntity<>(leaveRequests, HttpStatus.OK);
    }

    @GetMapping("/leave-requests/pending/count")
    public ResponseEntity<Integer> countPendingLeaveRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        int count = leaveRequestService.countPendingLeaveRequests();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }

    // Auth Requests
    @GetMapping("/auth-requests")
    public ResponseEntity<List<AuthRequest>> getAuthRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<AuthRequest> authRequests = authRequestService.getAllAuthRequests();
        return new ResponseEntity<>(authRequests, HttpStatus.OK);
    }

    @GetMapping("/auth-requests/pending")
    public ResponseEntity<List<AuthRequest>> getPendingAuthRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<AuthRequest> authRequests = authRequestService.getPendingAuthRequests();
        return new ResponseEntity<>(authRequests, HttpStatus.OK);
    }

    @GetMapping("/auth-requests/pending/count")
    public ResponseEntity<Integer> countPendingAuthRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        int count = authRequestService.countPendingAuthRequests();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }

    private void validateAuthentication(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("User not authenticated");
        }
    }
}
