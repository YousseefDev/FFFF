package com.example.version1.requests.loan;

import com.example.version1.requests.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanRequestRepository extends JpaRepository<LoanRequest, Long> {
    List<LoanRequest> findByUserId(Long userId);
    List<LoanRequest> findByStatus(String status);
    int countByStatus(String status);

    Long countByUserId(Long userId);

}
