  package com.example.version1.users;
  
  import lombok.RequiredArgsConstructor;
  import org.springframework.security.crypto.password.PasswordEncoder;
  import org.springframework.stereotype.Service;

  import java.util.Optional;

  @Service
  @RequiredArgsConstructor
  public class UserService {
  
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public long countAllUsers() {
      return userRepository.count(); // Assuming you want to count all users in the repository
    }

    public Long register(User user) {
      user.setPassword(passwordEncoder.encode(user.getPassword()));
      return userRepository.save(user).getId();
    }
    public Long getUserIdByEmail(String email) {
      Optional<User> userOptional = userRepository.findByEmail(email);
      return userOptional.map(User::getId).orElse(null);
    }

  }
